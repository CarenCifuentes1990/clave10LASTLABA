/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package par.e.impar;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class ParEImpar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a;
        
        System.out.println("ingrese numero");
        Scanner D1 = new Scanner (System.in);
        a = D1.nextInt();
        
        if (a%2==0) {
            System.out.println(a+"es par");
            
            }else {
                    System.out.println(a+"es impar");
                    }
    }
    
}
